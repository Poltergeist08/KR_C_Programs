#include <stdio.h>

#define MAXLINE 1000
#define MAXCOLUMN 50
#define TAB_STOP 8

int get_line(char line[], int max);
void write_folded(char line[], int len, int col, int tab);

int main() {
	char line[MAXLINE];
	int len;	

	while(len = (getline(line, MAXLINE)) > 0)
		write_folded(line, len, MAXCOLUMN, TAB_STOP);
}

int get_line(char line[], int max) {
	int i, c;
	for(i = 0; i < (max - 1) && (c = getchar()) != EOF && c != '\n'; ++i)
		line[i] = c;
	
	if(c == '\n') {
		line[i] = c;
		++i;
	}
	
	line[i] = c;

	return i;
}

void write_folded(char line[], int len, int col, int tab) {
	int i, line_len, state, c;
	state = line_len = 0;

	for (i = 0; i < len; ++i) {
		c = line[i];

		if (line_len >= col) {
			putchar('\n');
			line_len = 0;
		}
		if (c == ' ')
			state = 0;
		else if (c == '\t') {
			line_len += (tab - i % tab);
			--line_len;
		}
		else if (c == '\n')
			state = 0;
		else
			state = 1;

		++line_len;
	} 
}
