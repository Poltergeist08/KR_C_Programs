#include <stdio.h>

#define TAB_STOP 8
#define WIDTH 20
#define MAXWORD 1000

void clean_char_array(char line[], int max);

int main() {
	int i, wordpos, linepos, c;
	char word[MAXWORD];
	wordpos = i = linepos = 0;

	clean_char_array(word, MAXWORD);

	for (i = 0; i < WIDTH; ++i)
		printf("%d", i % 10);
	putchar('\n');

	while((c = getchar()) != EOF) {
		if (linepos + 1 == WIDTH) {
			linepos = 0;
			putchar('\n');
		}

		if (c != ' ' && c != '\t' && c != '\n' && wordpos + 1 < MAXWORD) { // if not blank we're in a word, we're saving the words letters and incrementing the index (lenght)
			word[wordpos] = c;
			++wordpos;
		}
		else if (wordpos > 0) {
			if (wordpos + linepos < WIDTH) { // if word doesnt breach line limit
				printf("%s", word);
				linepos += wordpos;
			}
			else if (wordpos + linepos >= WIDTH && wordpos < WIDTH) { // if word breaches line limit but doesnt take up more than one line
				printf("\n%s", word);
				linepos = wordpos;
			}
			else if (wordpos >= WIDTH) { // if word takes up more than the entire line
				for (i = 0; i < wordpos; ++i) {
					if (linepos == WIDTH - 1) {
						if (i > 0)
							putchar('-');
						putchar('\n');
						linepos = 0;
					}
					++linepos;
					putchar(word[i]);
				}
			}

			clean_char_array(word, MAXWORD);
			wordpos = 0;
		}
		// printf("%d | %d | %c | %s\n", wordpos, linepos, c, word);
	
		// handling blanks adding to linepos	
		if (c == ' ') {
			++linepos;
			putchar(c);
		}
		else if (c == '\n') {
			linepos = 0;
			putchar(c);
		}
		else if (c == '\t') {
			linepos += (TAB_STOP - linepos % TAB_STOP);
			if (linepos <= WIDTH)
				putchar(c);
			else {
				linepos = 0;
				putchar('\n');
			}
		}
	}

	// copy of process for printing words in order to fit the line
	// this is here so after reaching EOF the saved word can still print
	if (wordpos + linepos < WIDTH) { 
			printf("%s", word);
			linepos += wordpos;
		}
	else if (wordpos + linepos >= WIDTH && wordpos < WIDTH) { 
		printf("\n%s", word);
		linepos = wordpos;
	}
	else if (wordpos >= WIDTH) { 
		for (i = 0; i < wordpos; ++i) {
			if (linepos == WIDTH - 1) {
				if (i > 0)
					putchar('-');
				putchar('\n');
				linepos = 0;
			}
			++linepos;
			putchar(word[i]);
		}
	}
	
	return 0;
		
}

void clean_char_array(char line[], int max) {
	int i;
	for (i = 0; i < max; ++i)
		line[i] = '\0';
}
