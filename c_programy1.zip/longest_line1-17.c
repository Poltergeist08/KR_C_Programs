#include <stdio.h>
#define MAXLINE 1000

int get_line(char line[], int maxlength);

int main() {
	int len;
	int max;
	char line[MAXLINE];
	char longest[MAXLINE];

	max = 0;
	while((len = get_line(line, MAXLINE)) > 0)
		if (len > 80)
			printf("\n%s (%d)\n", line, len);
	
	return 0;
}

int get_line(char s[], int lim) {
	int c, i;
	
	for (i = 0; (c = getchar()) != EOF && c != '\n'; ++i)
		if (i < lim - 1)
			s[i] = c;
	if (i < lim - 1) {
		if (c == '\n') {
			s[i] = c;
			++i;
		}
		s[i] = '\0';
	} else {
		if (c == '\n')
			s[lim - 2] = '\n';
		s[lim - 1] = '\0';
	}

	return i;
}
