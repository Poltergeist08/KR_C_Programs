#include <stdio.h>

int main() {
	int c, i, j; 
	int charlens[128], maxcharoccur, max_chars_index; 
	maxcharoccur = max_chars_index = 0;
		
	// filling array with zeros
	for(i = 0; i < 128; ++i)
		charlens[i] = 0;
	
	// main loop, which loads the input
	while ((c = getchar()) != EOF) { 
		if (c >= 0 && c <= 127) {
			++charlens[c];
		}
	}
	
	// header
	printf("\nFREKVENCE RŮZNÝCH ZNAKŮ:\n");

	// calculating variables based on input
	for (i = 0; i < 128; ++i)
		if (charlens[i] > maxcharoccur) {
			maxcharoccur = charlens[i];
			max_chars_index = i;
		}
		
	// generating histogram
	for (i = maxcharoccur; i > 0; --i) { 
		for (j = 0; j < 128; ++j) {
			if (charlens[j] >= i)	
				printf("#  ");
			else if (charlens[j] > 0)
				printf("   ");
		}
		printf("\n");
	}

	for (i = 0; i < 128; ++i)
		if (charlens[i] > 0)
			if (i == 9)
				printf("\\t ");
			else if (i == 10)
				printf("\\n ");
			else if (i == 32)
				printf("' '");
			else
				printf("%-3c", i);

	
	// this is a bonus - using the previously calculated variables to show the user the most frequent char count of a word and the amount of occurances of that word
	if (maxcharoccur == 0)
		printf("VSTUP NEOBSAHUJE ŽÁDNÉ VHODNÉ ZNAKY\n");
	else {
		printf("\nNEJČASTĚJŠÍ JE ZNAK: ");
		if (max_chars_index == 9)
			printf("\\t");
		else if (max_chars_index == 10)
			printf("\\n");
		else if (max_chars_index == 32)
			printf("' '");
		else
			printf("%c", max_chars_index);
		printf(" (%d)\n", maxcharoccur);	
	}
}
