#include <stdio.h>


#define MAXLENGTH 1000

int rmBlanks(char from[], int len, int max);
int getLine(char line[], int max);

int main() {
	char line[MAXLENGTH];
	int len;

	while ((len = getLine(line, MAXLENGTH)) > 0) {
		if (rmBlanks(line, len, MAXLENGTH) > 1)
			printf("%s", line);
	}
}

int getLine(char line[], int max) {
	int i, c;

	for (i = 0; (c = getchar()) != '\n' && c != EOF; ++i) 
		if (i < MAXLENGTH - 1)
			line[i] = c;

	if (i < max - 1) {
		if (c == '\n') {
			line[i] = c;
			++i;
		}
		line[i]	= '\0';
	}
	else {
		if (c == '\n')
			line[max - 2] = '\n';
		line[max - 1] = '\0';
	}

	return i;
}

int rmBlanks(char from[], int len, int max) {
	int state, i, j, k;
	char temp1[max], temp2[max];
	state = j = k = 0;

	if (len > max - 1)
		len = max - 1;
	
	// beginning to end, don't copy until we're off the first blanks
	for (i = 0; i < len; ++i) {
		if (!state && from[i] != ' ' && from[i] != '\t')
			state = 1;
		if (state) {
			temp1[j] = from[i];
			++j;
		}
	}

	// resetting state to 0
	state = 0;

	// back to front, the first character here is skipped, because it is the null terminator, the new line is skipped too, if there is one
	for (i = j - 1; i >= 0; --i) {
		if (!state && temp1[i] != ' ' && temp1[i] != '\t' && temp1[i] != '\n')
			state = 1;
		if (state) {
			temp2[i] = temp1[i];
			++k;
		}
	}
	
	// overwriting from[]
	for (i = 0; i < k; ++i)
		from[i] = temp2[i];
	
	// in case a \n was overwritten
	if (temp1[j - 1] == '\n') {
		from[k] = '\n';
		++k;
		from[k] = '\0';
	}
	else
		from[k] = '\0';
	
	return k;
}
