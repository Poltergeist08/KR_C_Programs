#include <stdio.h>
#define TAB_STOP 8

int main() {
	int i, j, c;
	i = 0;

	while ((c = getchar()) != EOF) {
		if (c == '\t')
			for (j = TAB_STOP - (i) % TAB_STOP; j > 0; --j) {				
				putchar(' ');
				++i;
			}
		else
			putchar(c);

		if (c == '\n') {
			// printf("%d\n", i);
			i = 0;
		}	
		else if (c != '\t')
			++i; 
	}

	return 0;
}
