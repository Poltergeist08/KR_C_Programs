#include <stdio.h>

#define IN 1
#define OUT 0

int main() {
	int c, words, nl, nt, nc, state;
	nt = nc = words = state = 0;
	nl = 1;
	
	while ((c = getchar()) != EOF) {
		++nc;
		if (c == '\n')
			++nl;
		if (c == '\t')
			++nt;

		if (c == '\n' || c == '\t' || c == ' ')
			state = OUT;
		else if (state == OUT) {
			state = IN;
			++words;
		}
	}
	
	printf("\nlines: %d, tabs: %d, words: %d, characters: %d\n", nl, nt, words, nc);
}
