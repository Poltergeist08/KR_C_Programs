#include <stdio.h>

int main() {
	int c;
	double blanks;
	double tabs;
	double nl;
	
	while ((c = getchar()) != EOF) {
		if (c == ' ')
			++blanks;
		else if (c == '\t')
			++tabs;
		else if (c == '\n')
			++nl;
	}

	printf("blanks: %.0f, tabs: %.0f, newlines: %.0f\n", blanks, tabs, nl);
}
