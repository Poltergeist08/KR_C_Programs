#include <stdio.h>
#define TAB_STOP 8

int main() {
	int i, space, space_start, c, prev_c;
	i = space = prev_c = 0;

	while ((c = getchar()) != EOF) {
		if (c == ' ') { // if c is SPACE, save index of first SPACE, start counting SPACEs
			if (space == 0)
				space_start = i;
			++space;

			if (space == (TAB_STOP - space_start % TAB_STOP)) { // if there are enough SPACEs to reach the next tab stop, print a tab and reset counting of SPACEs
				if (space > 1) {
					c = '\t';
					putchar(c);
					//printf("\\t");
					space = 0;
				}
				else if (space == 1) {
					putchar(c);
					space = 0;
				}
			}
		}
		else if (prev_c == ' ') { // if we're no longer in a sequence of spaces, print all of the spaces that couldn't be converted to tabs
			for (space; space > 0; --space) {
				putchar(' ');
				// printf("SPACE ");
			}
			putchar(c); // also just print the non-space character
		}
		else
			putchar(c); // this is if we're already past the first letter in a word or in the first character in a line that isn't a space
		
		if (c == '\n') //we want to reset the index when entering a new line
			i = 0;
		else
			++i;		

		prev_c = c; // saving previous char
		
		// printf("\n|%d;%c;%d|\n", i, prev_c, space);
	}

	return 0;
}
