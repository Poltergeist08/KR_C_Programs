#include <stdio.h>

int main() {
	int c;

	// precedence of comparison is higher than that of assignment
	while ((c = getchar()) != EOF)
		printf("%d\n", c);				
	
	printf("EOF: %d\n", EOF);	
}

