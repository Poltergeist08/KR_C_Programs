#include <stdio.h>

#define IN 1
#define OUT 0
#define MAX_LENGTH 999

int main() {
	int c, i, j, state, loop; 
	int wlen, maxwlen, wlens[MAX_LENGTH], maxwoccur, max_wlens_index; 
	state = OUT; 
	loop = IN;
	wlen = maxwlen = maxwoccur = max_wlens_index = 0;
		
	// filling array with zeros
	for(i = 0; i < MAX_LENGTH; ++i)
		wlens[i] = 0;
	
	// main loop, which loads the input
	while (loop) { 
		c = getchar();
		if(c == ' ' || c == '\t' || c == '\n' || c == EOF) {
			if (state == IN) {
				if (wlen > maxwlen)
					maxwlen = wlen;
				++wlens[wlen - 1];
				wlen = 0;
			}	
			if (c == EOF)
				loop = OUT;	
			state = OUT;
		}
		else {
			state = IN;
			++wlen;
		}
	}
	
	// header
	printf("\nFREKVENCE SLOV S RŮZNÝMI POČTY PÍSMEN:\n");

	// calculating variables based on input
	for (i = 0; i < maxwlen; ++i)
		if (wlens[i] > maxwoccur) {
			maxwoccur = wlens[i];
			max_wlens_index = i;
		}
		
	// generating histogram
	for (i = maxwoccur; i > 0; --i) { 
		for (j = 0; j < maxwlen; ++j) {
			if (wlens[j] >= i)	
				printf("#  ");
			else
				printf("   ");
		}
		printf("\n");
	}

	for (i = 1; i <= maxwlen; ++i)
		printf("%-3d", i);
	
	// this is a bonus - using the previously calculated variables to show the user the most frequent char count of a word and the amount of occurances of that word
	if (maxwoccur == 0)
		printf("VSTUP NEOBSAHUJE ŽÁDNÁ SLOVA\n");
	else
		printf("\nNEJČASTĚJŠÍ JSOU SLOVA %d-PÍSMENNÁ (%d)\n",max_wlens_index + 1, maxwoccur);
}
