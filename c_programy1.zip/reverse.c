#include <stdio.h>
#define MAXLENGTH 1000

int getLine(char line[], int max);
void reverse(char line[], int len);

int main() {
	char line[MAXLENGTH];
	int len;

	while ((len = getLine(line, MAXLENGTH)) > 0) {
		reverse(line, len);
		printf("%s", line);
	}
}

int getLine(char line[], int max) {
	int i, c;

	for (i = 0; (c = getchar()) != '\n' && c != EOF; ++i) 
		if (i < MAXLENGTH - 1)
			line[i] = c;

	if (i < max - 1) {
		if (c == '\n') {
			line[i] = c;
			++i;
		}
		line[i]	= '\0';
	}
	else {
		if (c == '\n')
			line[max - 2] = '\n';
		line[max - 1] = '\0';
	}

	return i;
}

void reverse(char line[], int len) {
	int i, j, newline;
	char temp[len + 1];
	j = newline = 0;
	
	if(line[len - 1] == '\n') {
		newline = 1;
		--len;
	}

	for (i = len - 1; i >= 0; --i) {
		temp[j] = line[i];
		++j;
	}

	for (i = 0; i < j; ++i)
		line[i] = temp[i];

	if (newline) {
		line[j] = '\n';
		++j;
	}
	line[j] = '\0';
}
