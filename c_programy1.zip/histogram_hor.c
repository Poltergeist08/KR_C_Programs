#include <stdio.h>

#define IN 1
#define OUT 0
#define MAX_LENGTH 999

int main() {
	int c, i, j, state, loop; 
	int wlen, maxwlen, wlens[MAX_LENGTH]; 
	state = OUT; 
	loop = IN;
	wlen = maxwlen = 0;
		

	for(i = 0; i < MAX_LENGTH; ++i)
		wlens[i] = 0;
	
	while (loop) { 
		c = getchar();
		if(c == ' ' || c == '\t' || c == '\n' || c == EOF) {
			if (state == IN) {
				if (wlen > maxwlen)
					maxwlen = wlen;
				++wlens[wlen - 1];
				wlen = 0;
			}	
			if (c == EOF)
				loop = OUT;	
			state = OUT;
		}
		else {
			state = IN;
			++wlen;
		}
	}

	printf("\nFREKVENCE SLOV S RŮZNÝMI POČTY PÍSMEN:\nČÍS.\tPOČET\n");
	
	for (i = 0; i < maxwlen; ++i) {
		printf("%3d - ", i + 1);
		for (j = 0; j < wlens[i]; ++j)
			printf("#");
		printf(" (%d)\n", wlens[i]);
	}
}
