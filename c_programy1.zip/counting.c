#include <stdio.h>

int main() {
	int c;
	int c_buff = 0;
	double nc;
	double nl;

	while ((c = getchar()) != EOF)
	{
		if (c == '\n')
			++nl;
		++nc;
		if (c_buff == ' ' && c == ' ') {
			c_buff = c;
			continue;
		}
		
		putchar(c);	
		c_buff = c;
	}
	printf("chars: %.0f lines: %.0f\n", nc, nl);
}

