#include <stdio.h>

int main() 
{	
	float fahr, cels;
	float lower, upper, step;	
	
	lower = 0; /* lower limit of temperature scale */
	upper = 300;
	step = 20; /* step size */
	
	cels = lower;

	printf("%3s %6s\n", "C", "F");

	while(cels <= upper) {
		fahr = cels * (9.0/5.0) + 32.0;
		printf("%3.0f %6.1f\n", cels, fahr);
		cels = cels + step;
	}	

	printf("Finished!\n");

}

