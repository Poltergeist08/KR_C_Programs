#include <stdio.h>

#define STEP 1
#define LOWER 0
#define UPPER 50

float toFahrenheit(float c);

int main() 
{	
	float cels;
	cels = LOWER;

	printf("%3s %6s\n", "C", "F");

	while(cels <= UPPER) {
		printf("%3.0f %6.1f\n", cels, toFahrenheit(cels));
		cels += STEP;
	}	

	printf("Finished!\n");

}

float toFahrenheit(float c) {
	return (c * (9.0/5.0) + 32);
}
